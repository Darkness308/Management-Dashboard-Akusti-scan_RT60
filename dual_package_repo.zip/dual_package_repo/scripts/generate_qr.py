# später: QR-Codes für PDF Deckblätter erzeugen (z.B. qrcode lib)
