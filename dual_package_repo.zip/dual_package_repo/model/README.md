# LLM & RAG (Skizze)
- Start: lokal kleines Modell (CPU/GPU), RAG auf PDFs/Reports
- Später: Server mit vLLM/text-generation-inference
- Feintuning: LoRA/PEFT auf Domänentexten (keine Roh-Audiodaten)
- DSGVO: Pseudonymisierung, Data/Model Cards
