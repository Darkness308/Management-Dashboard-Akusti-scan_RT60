-- Messdatenbank (SQLite/Postgres kompatibel)
CREATE TABLE IF NOT EXISTS rooms (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  volume_m3 REAL,
  purpose TEXT,            -- Nutzung (Klasse, Büro, etc.)
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS materials (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS measurements (
  id TEXT PRIMARY KEY,
  room_id TEXT NOT NULL REFERENCES rooms(id),
  date TIMESTAMP NOT NULL,
  mic_model TEXT,
  method TEXT,             -- T20/T30 etc.
  notes TEXT
);

CREATE TABLE IF NOT EXISTS ir_files (
  id TEXT PRIMARY KEY,
  measurement_id TEXT NOT NULL REFERENCES measurements(id),
  path TEXT NOT NULL,      -- Pfad zur WAV/FLAC
  sha256 TEXT NOT NULL,
  samplerate INTEGER,
  channels INTEGER
);

CREATE TABLE IF NOT EXISTS bands (
  id INTEGER PRIMARY KEY,  -- 1..n für 1/3-Oktav
  center_hz INTEGER NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS rt_values (
  measurement_id TEXT NOT NULL REFERENCES measurements(id),
  band_id INTEGER NOT NULL REFERENCES bands(id),
  t20 REAL, t30 REAL, t60_est REAL,
  PRIMARY KEY (measurement_id, band_id)
);

-- Embeddings für RAG (pgvector in Postgres)
-- CREATE EXTENSION IF NOT EXISTS vector;  -- Postgres/pgvector
-- CREATE TABLE IF NOT EXISTS docs (
--   id TEXT PRIMARY KEY,
--   kind TEXT,         -- 'report','whitepaper','note'
--   text TEXT,
--   embedding vector(1536)
-- );
