# Dual-Package Repo (HTML ↔ PDF ↔ Daten)
Minimaler Startpunkt. Offline-HTML-Konzepte, Reports als Markdown, Datenbank-Schema.

## Schnellstart
```bash
make serve        # startet http://localhost:8888 (apps/site)
make schema       # erstellt SQLite DB (data/local.db)
make pdf          # rendert docs/reports/*.md (Pandoc erforderlich)
```

## Struktur
- apps/site: HTML-Module (Hub: index.html)
- docs/reports: Report-Templates (MD→PDF)
- data: Schema (SQLite/Postgres kompatibel)
- scripts: Tools (z.B. QR)
- .github/workflows: CI skeleton
- model: LLM/RAG-Notizen

## Offline-Hinweis
Einige Seiten nutzen CDN-JS/CSS. Für echten Offline-Betrieb später bundlen oder Service Worker + lokale Bundles.
