---
title: "Raumakustik-Report (Beispiel)"
author: "MSH audio"
version: "0.1.0"
date: "`date +%Y-%m-%d`"
---

# Metadaten
- Projekt: {{projekt_name}}
- Raum: {{raum_bez}}
- Volumen [m³]: {{volumen}}
- Messdatum: {{datum}}
- Setup: Klasse-1-Mikrofon, Impuls (T20/T30)

# Soll–Ist
| Band (Hz) | Soll T60 (s) | Ist T20/T30 (s) | Abweichung | Ampel |
|---:|---:|---:|---:|:--:|
| 125 | 0.8 | 1.2 | +0.4 | 🔴 |
| 250 | 0.7 | 0.9 | +0.2 | 🟠 |
| 500 | 0.6 | 0.6 | 0.0 | 🟢 |

# Maßnahmen
- 12 m² perforiertes Holzpaneel (500–1000 Hz), erwartet ΔT ≈ −0.2 s
- 8 m² Mineralwolle-Deckensegel, erwartet ΔT ≈ −0.15 s

> **Scope-Hinweis:** Orientierende Messung. Für Abnahmen ISO 3382-konformes Protokoll beilegen.
